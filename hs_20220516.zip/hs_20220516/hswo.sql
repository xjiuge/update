ALTER  table public.hs_satisfaction_statistic ADD COLUMN keyword varchar(50);
COMMENT ON COLUMN "public"."hs_satisfaction_statistic"."keyword" IS '关键字';